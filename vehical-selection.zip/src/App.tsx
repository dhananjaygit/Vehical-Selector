import CarSelector from './components/CarSelector';

function App() {
  return (
    <div className="App">
      <CarSelector />
    </div>
  );
}

export default App;
